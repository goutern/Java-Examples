package com.company;

public interface Shape {
    public double  area();
}
