package com.company;

public interface Fly {
    public void flies();
}
