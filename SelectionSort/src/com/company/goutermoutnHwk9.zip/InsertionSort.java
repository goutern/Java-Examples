package com.company;

public class InsertionSort {
    public static void sort(double[] a,
                            int begin, int end) {
        if ((end - begin) >= 1) {
            int splitPoint = split(a, begin, end);
            sort(a, begin, splitPoint);
            sort(a, splitPoint + 1, end);
            join(a, begin, splitPoint, end);
        }//else sorting one (or fewer) elements
        //so do nothing.
    }

    private static int split(double[] a,
                             int begin, int end) {
//        int index = indexOfSmallest(begin, a, end);
//        interchange(begin, index, a);
        return end - 1;
    }

    private static void join(double[] a, int begin,
                             int splitPoint, int end) {
        for(int i = begin; i < end; i++){
            if(a[end] < a[i]){
                for(int j = end; j > i; j--){
                    interchange(j-1, j, a);
                }
            }
        }

    }

    private static int indexOfSmallest(int startIndex,
                                       double[] a, int endIndex) {
        double min = a[startIndex];
        int indexOfMin = startIndex;
        int index;
        for (index = startIndex + 1;
             index < endIndex; index++)
            if (a[index] < min) {
                min = a[index];
                indexOfMin = index;
        //min is smallest of a[startIndex]
        //through a[index]
            }
        return indexOfMin;
    }

    private static void interchange(int i, int j, double[] a) {
        double temp;
        temp = a[i];
        a[i] = a[j];
        a[j] = temp; //original value of a[i]
    }
}


